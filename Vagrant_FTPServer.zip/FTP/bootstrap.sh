#!/usr/bin/env bash

apt-get update

sudo apt-get -y install git build-essential tree curl


#############################################
# Installation of vsftpd
#############################################
sudo apt-get -y install vsftpd
