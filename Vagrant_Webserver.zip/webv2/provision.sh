apt-get -y update

apt-get -y install nginx

rm -rf /etc/nginx/sites-enabled
rm -rf /etc/nginx/default
cp -r /vagrant/sites-enabled /etc/nginx/
#cp -r /vagrant/sites-enabled/default /etc/nginx/

service nginx start